# Handoff: The Grid — API documentation site redesign

## Overview

A redesign of the public documentation site for **The Grid** (`data.sierragridteam.org`), the
read-only `/api/v1` API published by S.I.E.R.R.A. — Signal Integrity & Emergency Radio Response
Alliance, a volunteer 501(c)(3) serving the central Sierra.

The site does double duty: it teaches the API *and* it is a working client of it. The original
was a single dark, dense terminal-style page where the prose and the data competed and neither
won; it also degraded poorly to mobile. This redesign separates the two jobs typographically —
**paper for reading, black for data** — keeps every value live, and puts the data first.

Three things drive the design:

1. **Nothing is a fixture.** Every number, record, timestamp, geometry and health status is
   fetched from the live public API at render time. The API is keyless, read-only and CORS-open,
   so the browser is a legitimate client.
2. **Fail loud.** The API's central contract is that absence is never an all-clear —
   `activeEvacuations` is `int | null` and `null` means *unknown*, never zero. The design obeys
   that contract in its own UI: unknowns render as words, unavailable map layers are suppressed
   rather than drawn empty, and a blocked fetch never becomes a 0.
3. **The docs sit beside the data they describe.** Field specs are paired with a live value from
   a real record; endpoint examples are runnable and show the actual response.

## About the Design Files

The files in this bundle are **design references created in HTML** — prototypes that show the
intended look and behaviour. They are not production code to copy directly.

`Grid API Docs Broadsheet.dc.html` is written as a "Design Component": a single file with an
HTML template and a companion JavaScript class, rendered by a small in-house runtime
(`support.js`). Do **not** port that runtime. The task is to **recreate these designs in the
target codebase's own environment** — React, Vue, Svelte, Astro, a static site generator, or
whatever the real site is built on — using its established patterns, router and data layer. If
no environment exists yet, pick the most appropriate framework for a mostly-static
documentation site with a few live data views (Astro or Next.js both fit well) and implement
there.

The logic class is a useful specification even though it is not shippable: it contains the exact
endpoint list, parameter tables, field documentation strings, severity scale, fallback data and
state machine. Lift those values verbatim.

## Fidelity

**High fidelity.** Colours, type, spacing, borders and copy are final and should be recreated
faithfully. Every hex value, font size and rule weight in this README is what the prototype
actually renders. Where the target codebase already has a design system, reconcile with it — but
the paper/black split, the Archivo display weights and the severity ramp are load-bearing and
should survive.

Two things are explicitly **not** final:

- The Leaflet basemap choice (CARTO dark) is a placeholder for whatever tile source the real
  site is licensed for.
- The cached fallback data (see *Offline and failure behaviour*) exists so the design can be
  reviewed in a sandbox where outbound fetches are blocked. In production, decide whether to
  keep a small cached sample at all; if you drop it, the loud-unknown path must still work.

---

## Information architecture

The nav reproduces the live site's three groups and ten destinations exactly:

| Group     | Destination | Path hint       | Screen in the prototype                  |
| --------- | ----------- | --------------- | ---------------------------------------- |
| OVERVIEW  | Grid Info   | `/api/v1`       | Front page (the broadsheet deck)         |
| EXPLORE   | Events      | `/events`       | Event browser + event detail             |
| EXPLORE   | Map         | `/map`          | GeoJSON layer viewer                     |
| EXPLORE   | Roads       | `/roads`        | Road incidents, and the conditions split |
| EXPLORE   | Mesh        | `/mesh`         | MeshCore node table                      |
| EXPLORE   | Places      | `/places`       | Place directory                          |
| EXPLORE   | Sources     | `/sources`      | Feed health board                        |
| EXPLORE   | History     | `/history`      | Cross-event revision list                |
| REFERENCE | Docs        | `/api/v1 ref`   | Endpoint reference + Event envelope      |
| REFERENCE | MCP         | `for agents`    | Model Context Protocol guide             |

Docs is deliberately **one** page (endpoints, envelope, severity, lifecycle, geometry) matching
the live site, not two.

---

## Screens / Views

### 1. Grid Info (front page)

**Purpose.** Tell a visitor what is happening in the region right now, then teach them to fetch
it themselves. It is the front door for both an engineer integrating the API and an ops user
checking state.

**Layout.** Full-bleed black deck at the top of the content column, then paper below.

The deck (`background: #14161a`, `color: #f4f1ea`, padding `26px clamp(14px,3vw,32px) 30px`,
inner `max-width: 1280px; margin: 0 auto`):

- **Dateline** — mono 10px, `letter-spacing: 0.14em`, `color: #8a8f98`, items separated by a
  `#2c3037` pipe: place name in caps, then `MODE {mode}` in the state accent.
- **Hero sentence** — Archivo 900, `clamp(30px, 4.6vw, 56px)`, `line-height: 1.02`,
  `letter-spacing: -0.035em`, `max-width: 30ch`. Reads:
  *"**12 events** are active in Ebbetts Pass Corridor right now, **4 of them EXTREME**."*
  The two figures are wrapped in spans coloured with the state accent; the connective text is
  cream. This replaced an earlier bare 132px numeral, which carried no meaning until you read
  its label.
- **Sub-line** — mono 11px, `line-height: 1.75`, `#8a8f98`, two rows: (a) evacuation zones ·
  SEVERE count · MODERATE count · past-24h count, joined by ` · `; (b) the exact request that
  produced them plus `generatedAt`.
- **Lede** — `clamp(15px,1.6vw,18px)`, `line-height: 1.45`, `#d7dbe1`, `max-width: 58ch`,
  `margin-top: 24px`.
- **Count ledger** — `margin-top: 22px`, full content width,
  `display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 1px; background: #2c3037`
  so the gap paints as hairlines. Each cell: `box-sizing: border-box; padding: 10px 12px;
  background: #14161a`; value in Archivo 800 28px `font-variant-numeric: tabular-nums`; label in
  mono 8.5px, `letter-spacing: 0.1em`, `#6f7580`. Cells are EXTREME, SEVERE, MODERATE,
  EVACUATIONS.
  **Do not** use `auto-fit`/`minmax(88px, …)` here — it wraps to 3 + 1 and paints an empty
  fourth slot as a dark void. Four fixed tracks.

Below the deck, on paper (`#f4f1ea`):

- **TOP OF THE FEED** — eyebrow mono 9.5px `#b3261e`, then the lead record's headline in Archivo
  900 `clamp(24px,3vw,34px)`, its id/layer/rev/attribution in mono 10px, all above a
  `3px solid #14161a` rule. Then up to four more records as broadsheet rows (see *Record row*),
  each clicking through to Events with that record selected.
- **01 Your first request** — numbered section head: mono 10px `#b3261e` ordinal + Archivo 800
  22px title, `border-bottom: 3px solid #14161a`. Body copy, then a black response pane: header
  row with `GET` in `#7dd47d`, the path in cream mono 11.5px, and a copy-curl button; `<pre>`
  at mono 11.5px `line-height: 1.65` `#b8bdc6`, `max-height: 340px`, scrolling; footer row with
  status · ms · bytes · content-type.
- **02 Three contracts, not conventions** — three columns divided by `1px solid #cdc8be`. The
  middle one (FAIL LOUD) is marked with `box-shadow: inset 4px 0 0 #b3261e` and a `#b3261e`
  eyebrow. Headings Archivo 800 17px; body 14px `#4b5058`.
- **03 Conventions** — definition rows, `grid-template-columns: minmax(0,210px) minmax(0,1fr)`,
  `gap: 4px 24px`, `padding: 13px 0`, `border-bottom: 1px solid #cdc8be`. Term in mono 12px,
  definition 14px `#4b5058`.

**Calm state.** When nothing in the place is above MODERATE the accent flips from
`#ff5544` to `#7dd47d`: hero figures, MODE label. The hero's second clause changes from
"4 of them EXTREME" to "nothing above MODERATE", and zero-valued EXTREME/SEVERE ledger cells grey
to `#565d68`. Calm is a **positive assertion**, so it requires every input to be known — see
*Fail-loud rules*.

### 2. Events (browser + detail)

**Purpose.** The low-level view. Browse real records, open one, read its envelope, geometry and
full revision history.

**Layout.** Filter bar, echoed query, then a grid:
`grid-template-columns: minmax(280px, 380px) minmax(0, 1fr)` with `gap: 28px` when a record is
selected; a single full-width column when nothing is selected. Under 900px the list and the
detail swap — selecting a record replaces the list, and a "← back to list" button appears.

**Filter bar.** Three labelled chip groups — `layer` (all, wildfire, evacuation, weather_alert,
earthquake, road_incident, mesh), `severity_min` (any, MINOR, MODERATE, SEVERE, EXTREME),
`status` (open only / include closed) — above a `3px solid #14161a` rule, with the resulting
`GET …` URL printed in mono 10.5px `#5b616b` beneath. Changing any chip refetches.

**Record row** (used on Events, Roads, History and the front feed):
`display: flex` with a `6px` severity-coloured spine as the first child, then a
`padding: 10px 12px` body: a meta line (severity in mono 8.5px 700 `letter-spacing: 0.1em` in
the severity colour, layer slug in `#9a958c`, relative time right-aligned), the headline in
Archivo 700 15px, and the id in mono 9.5px `#5b616b`. `border-bottom: 1px solid #cdc8be`.
Selected row: `background: #e9e5dc`.

**Detail pane**, in order:

1. Badge row — severity as a filled chip (severity colour, white text, mono 9.5px 700), status
   in a `1px solid #14161a` outline chip, then `{layer} · rev {n}` in mono.
2. Headline — Archivo 900 `clamp(22px,2.8vw,30px)`, `letter-spacing: -0.03em`; id in mono 11px.
3. Geometry — a 420px-tall Leaflet map when `geometry.geojson` is present, drawn from the
   base64-decoded geometry, styled in the record's severity colour
   (`weight: 2, fillOpacity: 0.28`), points as `circleMarker` r7. Beneath it, bbox and centroid
   in mono 10px. When geometry is absent, an `#e9e5dc` note with
   `box-shadow: inset 4px 0 0 #14161a` explaining that null geometry is valid and must be
   rendered as a full-width banner sorted by `severityRank`, never dropped.
4. **Envelope** — the fusion of docs and data. Rows of
   `grid-template-columns: minmax(0,150px) minmax(0,1fr)`: field name in mono 11.5px `#5b616b`,
   then the live value in mono 12px `#14161a` (`white-space: pre-wrap`) with the field's spec
   sentence beneath in 12.5px `#8a8f98`.
5. **Revision timeline** — one block per revision: `rev {n}` in Archivo 800 17px `#b3261e`,
   observed/ingested ages, and a change count. Diffs are computed client-side by comparing each
   revision to the next one down, rendered as
   `grid-template-columns: minmax(0,148px) minmax(0,1fr)` rows with `box-shadow: inset 2px 0 0 #cdc8be`:
   field name, then old value struck through in `#9a958c`, a `#b3261e` arrow, new value in
   `#14161a`. Values over 90 chars are ellipsised. The oldest revision reads "first recorded
   revision — nothing to diff against".
6. **Requests behind this pane** — the two curl commands that produced the pane, in black bars
   with copy buttons.
7. **raw protojson** — a `<details>` disclosure holding the full record, `max-height: 420px`.

### 3. Map

**Purpose.** Fetch any of the nine `.geojson` layers and read its `metadata` block beside the
geometry.

**Layout.** Nine layer chips (wildfire, evacuation, weather_alert, earthquake, road_incident,
road_segment, chain_control, fire_weather, mesh_node) above a `3px` rule; echoed query; optional
loud banner; the map; then the metadata table.

**The map element is conditionally mounted.** This is the most important behaviour on the screen:
when the layer is unfetched, or its `metadata.sourceStatus` is `UNAVAILABLE`, the map element is
**absent from the DOM** — not present-and-empty. A rendered basemap with zero features reads as
"all clear", which §5 of the API contract forbids. Do not implement this with
`visibility: hidden` or an overlay; omit the element.

**Loud banner.** `background: #fdf1ef; border: 1px solid #b3261e; box-shadow: inset 4px 0 0 #b3261e`,
title in mono 10px caps `#b3261e`, body 13.5px. Three cases:
- no document (fetch failed or timed out) — "layer unavailable — state unknown, not clear";
- `sourceStatus: UNAVAILABLE` — "suppress this layer", features are empty by contract;
- `sourceStatus: STALE` — last-good features are shown, so render a data-age indicator computed
  from `generatedAt − lastSourceUpdate` (this case still draws the map).
When the metadata block parsed, the banner renders `metadata.sourceUrl` as a real link.

**Metadata table.** `grid-template-columns: minmax(0,160px) minmax(0,1fr)`, rows for layer, area,
sourceStatus, feature count, generatedAt, lastSourceUpdate, attribution, sourceUrl.

### 4. Roads

**Purpose.** Explain the two-idiom split, which is the single most confusing thing about roads in
this API, then list what is currently open.

Prose establishes that road *incidents* are events (`/events?layer=road_incident`) while road
*conditions* — congestion, chain control — are **not** events and exist only as the
`road_segment` and `chain_control` map layers. Then an "Incidents · N" section of record rows.
The empty state is written to avoid a false read: *"No active road incidents in this place.
Conditions still exist — an open road is baseline state, carried by the `road_segment` layer, not
by `/events`."* A closing line links the Map screen.

### 5. Mesh

**Purpose.** MeshCore node presence, and the caveat that its telemetry is not revisioned.

A table — Node (name in Archivo 700 15px, truncated public key in mono 9.5px beneath), Type,
SNR / RSSI, Hops, Heard. Prose states that presence is ambient `INFO` state excluded from
`totalActive`, severity counts and area mode; that telemetry is volatile and never mints a
revision; and that "when did this node last speak" should be answered from the event's
`observedAt`, not `telemetry.lastAdvertAt` (node clocks skew). Missing telemetry renders as
`—`, never 0.

### 6. Places

Place directory table — Place (name + id), Kind, Geometry (present with base64 length, or "bbox
only"), Parent. Kind filter chips (all kinds, AREA, COUNTY, TOWN, CORRIDOR, EVAC_ZONE, SITE) are
applied **client-side** because the directory is unpaginated and returns whole. Prose explains
that ids are `{kind}:{slug}`, slugs are globally unique, and both forms work anywhere a
`{place}` appears.

### 7. Sources

Feed health board — Source (name + id), Status as a filled chip (`#4d7c0f` OK, `#a16207` STALE,
`#b3261e` UNAVAILABLE), Poll interval, Last success as a relative age, Attribution. Prose states
the staleness rule (STALE once last success is older than `staleAfterSeconds`, default three poll
intervals) and instructs consumers to read live values rather than hard-code intervals. A closing
line carries the attribution obligation and the evacuation reference-only framing.

### 8. History

Cross-event revision list — record rows carrying `rev {n}`, severity/layer tag, ingest age,
headline and id.

**Known upstream bug, documented on the page in `#b3261e`:** the `from` bound does not filter.
A request with `from=2026-08-05T…` returns July revisions, and a place-scoped call returns only
weather alerts. The screen therefore fetches unfiltered and says so. **Re-test this before
shipping** — if it is fixed server-side, remove the note and restore the date-range controls.

### 9. Docs

One page, in order: Endpoint reference (eleven collapsible endpoints), then The Event envelope
(spec-beside-live-value table), the severity scale, the lifecycle diagram, and the geometry
base64 note.

**Endpoint entry.** Collapsed: `GET` in mono 9.5px 700 `#b3261e`, the path in mono
`clamp(12px,1.5vw,14.5px)`, a one-line purpose in 14px `#5b616b`, and a `+`/`—` affordance.
Expanded: a detail paragraph (`max-width: 70ch`), a parameter table (Param / Type / Semantics /
Default; param names in mono 12.5px `#b3261e`; header `border-bottom: 2px solid #14161a`), then
example URLs as **RUN** buttons. Pressing one fetches live and prints the real response in a black
pane with status (green when ok, `#e8a97d` otherwise) · ms · bytes. One endpoint is open by
default.

**Envelope table.** `grid-template-columns: minmax(0,1fr) minmax(0,1fr)`, `gap: 2px 28px`. Left:
field name in mono 13px 600 + type in mono 10.5px `#9a958c`, with the spec sentence beneath in
13.5px. Right: the live value from a sampled record, mono 12px on `#e9e5dc` with
`box-shadow: inset 3px 0 0 #14161a`, `white-space: pre-wrap`. A black bar above the table shows
the sampled record's id and a "next event" button that cycles through the fetched records.

**Severity scale.** Five rows, each a 74px filled block in the severity colour with the name in
white mono 9px 700, then rank and a one-line note. Copy states that the scale expresses response
urgency to the public, not physical magnitude — an Evacuation Order (EXTREME) intentionally
outranks an M5 earthquake (SEVERE) — and that colour is never the only signal.

### 10. MCP

Reproduces the live `/mcp-guide` content: the endpoint (`https://data.sierragridteam.org/mcp`,
Streamable HTTP, JSON-RPC 2.0 over POST, `GET` returns 405, geometry stripped for token
efficiency), the `mcpServers` config block, the `mcp-remote` stdio bridge, the `claude mcp add`
command, a table of the eight read-only tools with arguments and returns, and a table pairing
plain-language asks with the resulting tool call. Closes by noting the fail-loud contract crosses
the protocol boundary unchanged.

---

## Navigation

**Desktop (≥900px).** Sticky black sidebar, `width: 244px; min-width: 244px; min-height: 100vh`,
`background: #14161a`. Masthead block (`padding: 16px 16px 14px`, `border-bottom: 1px solid #2c3037`):
"THE GRID" in Archivo 900 19px, the host in mono 9.5px `#8a8f98`, a live health line with a
pulsing dot, then clock · read-only · no key. Then three groups, each a mono 9px
`letter-spacing: 0.18em` `#565d68` label with its items beneath. Item:
`display: flex; justify-content: space-between; padding: 9px 16px`, label in Archivo 700 15px,
path hint in mono 9.5px `#6f7580`. Active item: `background: #1f232a`,
`box-shadow: inset 3px 0 0 #ff5544`, label `#f4f1ea`. Footer block: schema line + a running count
of requests the page has made.

**Mobile (<900px).** Sidebar becomes a fixed left drawer (`width: 260px`, `z-index: 50`,
`box-shadow: 0 0 0 100vmax rgba(0,0,0,0.5)` as the scrim) toggled by a hamburger in a sticky
black top bar that also shows the current screen name and the health dot. Selecting a destination
closes the drawer.

Content column: `max-width: 1280px; margin: 0 auto`, padding `0 clamp(14px,3vw,32px) 110px`.

---

## Interactions & Behavior

- **Navigation** is client-side screen switching in the prototype; in the real site these are
  routes matching the path hints in the IA table.
- **Lazy loading.** Places, Mesh, Roads and History fetch on first visit. Each shows an explicit
  pending line ("fetching /places…") while in flight — a first click must never land on blank
  space. A screen whose fetch failed is un-marked so revisiting retries.
- **Map layer chips** refetch on click and tear down the previous Leaflet instance.
- **Event selection** fetches the record and its history in parallel.
- **RUN buttons** fetch a single example URL and render status, timing, byte count and body.
- **Copy buttons** write to the clipboard and flip their label to "copied" for 1400ms.
- **Clock** ticks once a second, formatted `HH:MM:SSZ` from `toISOString()`.
- **Fetch deadline.** Every request runs under an `AbortController` with a **6000ms** deadline.
  A hang must resolve to `{status: "timeout", error: "no response within 6000 ms — request
  abandoned"}` and take the failure path. Without this, a hanging endpoint leaves a screen on
  "fetching…" forever, which is neither a value nor an admission of unknown. (`/api/v1/history`
  was observed hanging indefinitely during design, which is how this was found.)
- **No animation** beyond the 2.6s health-dot pulse and Leaflet's own transitions. Scroll-wheel
  zoom is disabled on all maps so the page still scrolls over them.

## Fail-loud rules (contractual, not cosmetic)

These are obligations the API places on every consumer. The design implements them; the
implementation must keep them.

1. **`null` ≠ `0`.** `activeEvacuations: null` renders as "evacuation count unknown — not zero",
   never as 0 and never as blank.
2. **A blocked or failed fetch never renders as zero.** Stat values become `—` or the word
   UNKNOWN at heading size; the health pill turns `#ff5544` with "API unreachable — status
   unknown"; a banner names the reason and tells the reader how to replay the request.
3. **Calm requires complete knowledge.** The green state needs: a summary present, zero EXTREME,
   zero SEVERE, `activeEvacuations` non-null, `evacuationStatus === "OK"`, no UNAVAILABLE source,
   and a successful live fetch. Any unknown ⇒ not calm.
4. **UNAVAILABLE map layers are suppressed, not drawn.** The map element is absent; a banner links
   `metadata.sourceUrl`.
5. **STALE means show the age.** Last-good features render with a data-age indicator.
6. **Directive life-safety text is never rewritten.** Evacuation orders and instructions appear
   verbatim from `description`; AI enhancement is prohibited for that layer. Where a record has
   an `enhancement` block, badge the generated text and keep the verbatim `description`
   reachable.
7. **Attribution is displayed wherever data is rendered**, and evacuation data always carries its
   reference-only framing and the Genasys link.

## Offline and failure behaviour

The prototype ships a small **cached sample** — the last values the live API actually returned —
used only when a fetch fails, and always badged `CACHED SAMPLE` in a red banner that explains the
transport failure and how to replay it. This exists because the review sandbox blocks outbound
requests; it is also a reasonable production behaviour, but it is your call.

If you keep it: the badge must be unmissable, and a cached set whose newest timestamp has aged
out of the window it is answering must degrade to UNKNOWN rather than reporting a stale count as
current. If you drop it: every screen must still have a loud unknown state, because that is the
path that then runs.

## State Management

Screen state: `screen` (route), `narrow` (viewport < 900px), `navOpen` (mobile drawer),
`clock`, `tally` (requests made), `offline` (any fetch has failed).

Data state, each with its own error field: `sources`, `summary` (place summary), `events` (the
browser list), `deckEvents` (place-scoped, for the hero), `places`, `mesh`, `roads`, `hist`,
`mapDoc`; plus `sel` and `history` for the selected record, `results` keyed by endpoint index
for RUN output, and `loaded` marking which lazy screens have resolved.

Filter state: `layer`, `sevMin`, `closed`, `kind`, `mapLayer`, `sampleIdx`, `openEp`.

Derived per render: the calm flag, the past-24h count, severity counts, the annotated envelope
rows, the revision diffs, and the map's loud-banner decision.

## Data sources

Base URL `https://data.sierragridteam.org`, everything under `/api/v1/`. Read-only, keyless,
CORS-open. Responses are camelCase; query parameters are snake_case. Timestamps are RFC 3339.
Most reads carry a weak ETag.

Requests this design makes:

| Screen    | Request                                                          |
| --------- | ---------------------------------------------------------------- |
| all       | `/api/v1/sources`                                                |
| Grid Info | `/api/v1/places/ebbetts-pass/summary`                            |
| Grid Info | `/api/v1/events?place=ebbetts-pass&page_size=200` (hero counts)   |
| Grid Info | `/api/v1/events?place=ebbetts-pass&page_size=1` (first-request)   |
| Events    | `/api/v1/events?page_size=60` + filters                          |
| Events    | `/api/v1/events/{id}` and `/api/v1/events/{id}/history`          |
| Map       | `/api/v1/places/ebbetts-pass/map/{layer}.geojson`                 |
| Roads     | `/api/v1/events?layer=road_incident&place=ebbetts-pass`           |
| Mesh      | `/api/v1/events?layer=mesh&place=ebbetts-pass`                    |
| Places    | `/api/v1/places`                                                  |
| History   | `/api/v1/history?page_size=50`                                    |

`PLACE` is a single constant (`ebbetts-pass`) in the prototype. In production this should come
from the route or a place picker — `/api/v1/places` is the directory, and `/api/v1/places:resolve`
turns an address or lat/lng into containing places.

**Geometry decoding.** `Event.geometry.geojson` is proto `bytes`, which protojson renders as
base64. Decode before parsing, and remember coordinates are `[lng, lat]`:

```js
const g = event.geometry;                          // may be absent entirely
const geom = g?.geojson ? JSON.parse(atob(g.geojson)) : null;
```

`bbox` and `centroid` are always populated at ingest, so list views never decode. For map
rendering prefer the `.geojson` endpoints; the base64 field is for detail views.

## Design Tokens

**Surfaces**

| Token          | Hex       | Use                                                     |
| -------------- | --------- | ------------------------------------------------------- |
| paper          | `#f4f1ea` | Page background                                         |
| ink            | `#14161a` | Text, rules, and every data pane / deck / chrome surface |
| paper-sunken   | `#e9e5dc` | Value cells, selected rows, inline notes                |
| rule-strong    | `#14161a` | Section rules, 3px; table headers, 2px                  |
| rule           | `#cdc8be` | Row dividers on paper, 1px                              |
| rule-light     | `#e0dcd3` | Dense table dividers, 1px                               |
| ink-rule       | `#2c3037` | Dividers inside black surfaces                          |
| ink-raised     | `#1f232a` | Active nav item, bar troughs                            |

**Type on paper:** `#14161a` primary · `#3a3f47` body · `#4b5058` secondary · `#5b616b` muted ·
`#8a8f98` tertiary · `#9a958c` faint.
**Type on ink:** `#f4f1ea` primary · `#d7dbe1` secondary · `#b8bdc6` code · `#8a8f98` muted ·
`#6f7580` faint · `#565d68` labels.

**Accents**

| Token             | Hex       | Use                                                    |
| ----------------- | --------- | ------------------------------------------------------ |
| signal            | `#b3261e` | Accent on paper — ordinals, param names, rev numbers    |
| signal-on-ink     | `#ff5544` | Accent on black — hero figures, MODE, active nav marker |
| calm-on-ink       | `#7dd47d` | Calm-state accent, and `GET` / ok status in panes       |
| warn-on-ink       | `#e8a97d` | Non-ok status in response panes                        |

**Severity ramp** (always paired with the text label — never colour alone):

| Severity | Rank | Paper     | On ink    |
| -------- | ---- | --------- | --------- |
| EXTREME  | 4    | `#b3261e` | `#ff5544` |
| SEVERE   | 3    | `#c2410c` | `#e0913f` |
| MODERATE | 2    | `#a16207` | `#d0a24a` |
| MINOR    | 1    | `#4d7c0f` | `#4d9c3a` |
| INFO     | 0    | `#1d4ed8` | `#3d8bff` |

**Source status:** OK `#4d7c0f` · STALE `#a16207` · UNAVAILABLE `#b3261e`.

**Typography.** Three families, each with one job.

- **Archivo** (600–900) — display. All headings, record headlines, hero sentence, big numerals,
  nav item labels. Always tight: `letter-spacing` −0.01em to −0.05em, the largest sizes tightest.
- **IBM Plex Sans** (400–600) — prose, body copy, table cell text. Base 15px, `line-height: 1.55`,
  `text-wrap: pretty`.
- **IBM Plex Mono** (400–700) — every value, path, id, timestamp, field name, chip, eyebrow and
  label. If it came from the API or names something in it, it is mono.

Scale actually used: h1 `clamp(30px,4.4vw,46px)`/900 · hero `clamp(30px,4.6vw,56px)`/900 ·
h2 22px/800 · h3 17px/800 · record headline 15px/700 · body 15px · dense body 13.5–14px ·
mono value 11.5–12px · mono label 9–10.5px with `letter-spacing` 0.08–0.18em, uppercase.
Numerals use `font-variant-numeric: tabular-nums`.

**Spacing.** Section rhythm 34px between sections, 8px under a section rule, 12–14px row padding,
gaps of 1px (hairline grids), 4–6px (chips), 16–28px (columns). Chips and buttons: `padding: 4px 10px`,
`border: 1px solid #cdc8be` resting / `#14161a` active with inverted fill.

**Radii.** Effectively none — 0 everywhere except Leaflet's own controls and the circular status
dots. This is deliberate; rounded corners break the broadsheet read.

**Shadows.** No drop shadows. `box-shadow` is used only as a hairline device:
`inset Npx 0 0 <colour>` for left-edge markers, and `0 0 0 100vmax rgba(0,0,0,0.5)` as the mobile
drawer scrim.

## Assets

No image assets. No icons — the only glyphs are the `≡` hamburger, `+`/`—` disclosure marks and
the `──▶` lifecycle diagram, all text. Fonts are Archivo, IBM Plex Sans and IBM Plex Mono from
Google Fonts (`display=swap`); self-host them in production. Leaflet 1.9.4 from unpkg with CARTO
`dark_nolabels` tiles — replace with your licensed tile source, and note the CARTO/OSM
attribution requirement either way.

## Files

| File                                | What it is                                                                                  |
| ----------------------------------- | ------------------------------------------------------------------------------------------- |
| `Grid API Docs Broadsheet.dc.html`  | **The design to implement.** All ten screens. Template + logic class in one file.            |
| `Directions.dc.html`                | The exploration that led here — three overall directions, three broadsheet variants, four hero treatments. Useful for understanding why the final choices were made; not to be implemented. |
| `Grid API Docs.dc.html`             | The first (rejected) direction: paper docs with dark data panes, signal-red accent. Kept for reference. |
| `support.js`                        | The prototype runtime. **Do not port.** Present only so the HTML opens standalone.           |

Open any of them directly in a browser. The prototypes fetch the live API, so they need network
access; without it they fall back to the cached sample and show the loud banner, which is itself
worth seeing.

## Open questions for the implementer

1. **Place scope.** Everything is currently pinned to `ebbetts-pass`. Should the site have a place
   picker, or a route per place, or default to a resolved location?
2. **Cached sample.** Keep, or rely purely on loud-unknown states?
3. **`/api/v1/history`.** The `from` bound does not filter and the endpoint was observed hanging.
   Confirm current behaviour before shipping the History screen's caveat.
4. **Tiles.** Which basemap is the project licensed for?
5. **Docs page length.** Docs is one long page. If it needs an "on this page" rail, the section
   structure is already in place to generate one.
